#include "parser/hxs_parser.h"

static Hxs_BinopPrecedence BINOP_PRECEDENCE[] = {
    // Multiplicative
    {HXS_BINOP_MUL, 12},
    {HXS_BINOP_DIV, 12},
    {HXS_BINOP_MOD, 12},

    // Additive
    {HXS_BINOP_ADD, 11},
    {HXS_BINOP_SUB, 11},

    // Shift
    {HXS_BINOP_SHL, 10},
    {HXS_BINOP_SHR, 10},
    {HXS_BINOP_USHR, 10},

    // Relational
    {HXS_BINOP_LT, 9},
    {HXS_BINOP_LE, 9},
    {HXS_BINOP_GT, 9},
    {HXS_BINOP_GE, 9},

    // Equality
    {HXS_BINOP_EQ, 8},
    {HXS_BINOP_NEQ, 8},

    // Bitwise
    {HXS_BINOP_BIT_AND, 7},
    {HXS_BINOP_BIT_XOR, 6},
    {HXS_BINOP_BIT_OR, 5},

    // Logical
    {HXS_BINOP_AND, 4},
    {HXS_BINOP_OR, 3},

    // Assignment (right-associative)
    {HXS_BINOP_ASSIGN_ADD, 2},
    {HXS_BINOP_ASSIGN_SUB, 2},
    {HXS_BINOP_ASSIGN_MUL, 2},
    {HXS_BINOP_ASSIGN_DIV, 2},
    {HXS_BINOP_ASSIGN_MOD, 2},

    // Lowest
    {HXS_BINOP_IN, 1},
    {HXS_BINOP_SPREAD, 1}};
