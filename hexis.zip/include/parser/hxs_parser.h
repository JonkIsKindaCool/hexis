#pragma once

#include "ast/hxs_ast.h"

typedef struct
{
    HxsLexer *lexer;
    HxsArena *arena;

    jmp_buf error_jmp;
    char error_msg[512];
    bool has_error;
} HxsParser;

typedef struct
{
    HxsBinop op;
    int precedence;
} Hxs_BinopPrecedence;

HxsExpr *Hxs_initParser(HxsArena *arena, HxsLexer *lexer);

HxsExpr *Hxs_parse(HxsParser *parser);
HxsExpr *Hxs_parseMultiple(HxsParser *parser, HxsTokenKind ender);
HxsExpr *Hxs_parseExpression(HxsParser *parser);
HxsExpr *Hxs_parseStatement(HxsParser *parser);

bool Hxs_parser_peek(HxsParser *parser);
bool Hxs_parser_advance(HxsParser *parser);
bool Hxs_parser_expect(HxsParser *parser, HxsTokenKind expect, const char *err);
bool Hxs_parser_maybe(HxsParser *parser, HxsTokenKind kind);
void Hxs_parser_throw(HxsParser *parser, const char *fmt, ...);